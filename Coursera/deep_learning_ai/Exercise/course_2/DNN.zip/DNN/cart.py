# -*- coding: utf-8 -*-
"""
Created on Wed Jun 13 18:36:45 2018

@author: Zhai Xu
"""

import numpy as np
class tree:
    def _init_(self, value=None, left=None, right=None, results=None, col=-1, summary=None, data=None):
       self.value=value
       self.left=left
       self.right=right
       self.results=results
       self.col=col
       self.summary=summary
       self.data=data
   def    
        